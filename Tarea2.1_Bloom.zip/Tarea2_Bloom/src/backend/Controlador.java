package backend;

import java.io.*;
import java.util.*;

public class Controlador {
    private List<Pregunta> preguntas;
    private int indiceActual;

    public Controlador() {
        preguntas = new ArrayList<>();
        indiceActual = 0;
    }

    public boolean cargarPreguntas(String rutaArchivo) {
        preguntas.clear();
        try (BufferedReader br = new BufferedReader(new FileReader(rutaArchivo))) {
            String linea;

            while ((linea = br.readLine()) != null) {
                preguntas.add(new Pregunta(linea.trim()));
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Pregunta getPreguntaActual() {
        if (preguntas.isEmpty()) return null;
        return preguntas.get(indiceActual);
    }

    public boolean puedeRetroceder() {
        return indiceActual > 0;
    }

    public boolean puedeAvanzar() {
        return indiceActual < preguntas.size() - 1;
    }

    public void siguiente() {
        if (puedeAvanzar()) indiceActual++;
    }

    public void anterior() {
        if (puedeRetroceder()) indiceActual--;
    }
}