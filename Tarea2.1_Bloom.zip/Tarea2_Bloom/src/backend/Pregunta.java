package backend;

public class Pregunta {
    private String texto;

    public Pregunta(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}