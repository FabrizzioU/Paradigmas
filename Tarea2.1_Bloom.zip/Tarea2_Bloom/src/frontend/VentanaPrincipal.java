package frontend;

import backend.Controlador;
import backend.Pregunta;

import javax.swing.*;
import java.awt.*;
import java.io.File;

public class VentanaPrincipal {
    private JFrame frame;
    private JLabel lblPregunta;
    private JButton btnAnterior, btnSiguiente;
    private Controlador controlador;

    public VentanaPrincipal() {
        controlador = new Controlador();
    }

    public void mostrar() {
        frame = new JFrame("Visor de Preguntas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 200);
        frame.setLayout(new BorderLayout());

        lblPregunta = new JLabel("Cargue un archivo para comenzar", SwingConstants.CENTER);
        frame.add(lblPregunta, BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout());
        btnAnterior = new JButton("Atrás");
        btnSiguiente = new JButton("Siguiente");

        btnAnterior.setEnabled(false);
        btnSiguiente.setEnabled(false);

        botones.add(btnAnterior);
        botones.add(btnSiguiente);
        frame.add(botones, BorderLayout.SOUTH);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Archivo");
        JMenuItem cargar = new JMenuItem("Cargar CSV");
        cargar.addActionListener(e -> cargarArchivo());
        menu.add(cargar);
        menuBar.add(menu);
        frame.setJMenuBar(menuBar);

        btnAnterior.addActionListener(e -> {
            controlador.anterior();
            actualizarVista();
        });

        btnSiguiente.addActionListener(e -> {
            controlador.siguiente();
            actualizarVista();
        });

        frame.setVisible(true);
    }

    private void cargarArchivo() {
        JFileChooser chooser = new JFileChooser();
        int opcion = chooser.showOpenDialog(frame);
        if (opcion == JFileChooser.APPROVE_OPTION) {
            File archivo = chooser.getSelectedFile();
            if (controlador.cargarPreguntas(archivo.getAbsolutePath())) {
                actualizarVista();
            } else {
                JOptionPane.showMessageDialog(frame, "Error al leer el archivo.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void actualizarVista() {
        Pregunta actual = controlador.getPreguntaActual();
        if (actual != null) {
            lblPregunta.setText("<html><div style='text-align:center;'>" + actual.getTexto() + "</div></html>");
        } else {
            lblPregunta.setText("No hay preguntas.");
        }
        btnAnterior.setEnabled(controlador.puedeRetroceder());
        btnSiguiente.setEnabled(controlador.puedeAvanzar());
    }
}