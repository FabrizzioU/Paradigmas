# Programa Bloom

## Descripción
Aplicación java swing que permite cargar un archivo CSV con preguntas y navegar entre ellas usando botones "Atrás" y "Siguiente".

## Estructura del proyecto
- `src/backend/`: lógica de control y modelo
- `src/frontend/`: interfaz gráfica
- `recursos/items.csv`: archivo con preguntas (una por línea)

## Ejecución
1. Abre el proyecto en IntelliJ IDEA.
2. Ejecuta el main.
3. Carga el archivo CSV desde el menú "Archivo > Cargar CSV". o tambien el propio que tengas. (Ej para profesor)

## Formato del CSV
Una pregunta por línea con el tipo de nivel taxonomico, formato de pregunta, alternativas, etc. Estas se
diferencias asi: id,tipo,pregunta,opciones,respuesta_correcta,nivel_bloom,tiempo
