
import java.util.*;
import java.util.stream.*;

public class SistemaCalorias {

    record Plato(String nombre, int calorias) {}

    static final List<Plato> entradas = List.of(
        new Plato("Paella", 200),
        new Plato("Gazpacho", 150),
        new Plato("Pasta", 300),
        new Plato("Ensalada César", 180),
        new Plato("Sopa de Verduras", 120)
    );

    static final List<Plato> principales = List.of(
        new Plato("Filete de cerdo", 400),
        new Plato("Pollo asado", 280),
        new Plato("Bistec a lo pobre", 500),
        new Plato("Trucha", 160),
        new Plato("Bacalao", 300),
        new Plato("Salmón a la plancha", 350),
        new Plato("Lasaña", 450)
    );

    static final List<Plato> postres = List.of(
        new Plato("Flan", 200),
        new Plato("Naranja", 50),
        new Plato("Nueces", 500),
        new Plato("Yogurt", 100),
        new Plato("Helado", 250)
    );

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("--- Sistema de Gestión de Calorías ---");
            System.out.println("1. Calcular calorías de un menú");
            System.out.println("2. Ver combinaciones por límite calórico");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            String opcion = scanner.nextLine();

            switch (opcion) {
                case "1" -> calcularCaloriasMenu(scanner);
                case "2" -> mostrarCombinaciones(scanner);
                case "3" -> {
                    System.out.println("Gracias por usar el sistema.");
                    return;
                }
                default -> System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }

    private static void calcularCaloriasMenu(Scanner scanner) {
        Plato entrada = seleccionarPlato(scanner, entradas, "entrada");
        Plato principal = seleccionarPlato(scanner, principales, "plato principal");
        Plato postre = seleccionarPlato(scanner, postres, "postre");

        int total = entrada.calorias + principal.calorias + postre.calorias;
        System.out.println("Calorías totales del menú: " + total);
    }

    private static Plato seleccionarPlato(Scanner scanner, List<Plato> lista, String tipo) {
        while (true) {
            System.out.println("Seleccione una " + tipo + ":");
            lista.forEach(p -> System.out.println("- " + p.nombre));
            System.out.print("Nombre del plato: ");
            String input = scanner.nextLine();

            Optional<Plato> plato = lista.stream()
                .filter(p -> p.nombre.equalsIgnoreCase(input))
                .findFirst();

            if (plato.isPresent()) {
                return plato.get();
            } else {
                System.out.println("Plato no válido. Intente nuevamente.");
            }
        }
    }

    private static void mostrarCombinaciones(Scanner scanner) {
        System.out.print("Ingrese el límite máximo de calorías: ");
        int limite;
        try {
            limite = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Entrada no válida. Intente nuevamente.");
            return;
        }

        System.out.println("Combinaciones que no superan " + limite + " calorías:");
        List<String> combinaciones = entradas.stream()
            .flatMap(e -> principales.stream()
                .flatMap(p -> postres.stream()
                    .map(po -> Map.entry(List.of(e, p, po), e.calorias + p.calorias + po.calorias))
                )
            )
            .filter(entry -> entry.getValue() <= limite)
            .map(entry -> {
                List<Plato> platos = entry.getKey();
                return "* Entrada: " + platos.get(0).nombre + " (" + platos.get(0).calorias + " cal)\n" +
                       "  Principal: " + platos.get(1).nombre + " (" + platos.get(1).calorias + " cal)\n" +
                       "  Postre: " + platos.get(2).nombre + " (" + platos.get(2).calorias + " cal)\n" +
                       "  TOTAL: " + entry.getValue() + " calorías\n";
            })
            .toList();

        if (combinaciones.isEmpty()) {
            System.out.println("No hay combinaciones dentro del límite calórico.");
        } else {
            combinaciones.forEach(System.out::println);
        }
    }
}
